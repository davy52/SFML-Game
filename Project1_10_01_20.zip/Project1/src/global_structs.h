#pragma once

enum class GAME_STATE
{
	MAIN_MENU,
	PLAYING,
	PAUSE,
	F1,
	SETTINGS
};
#pragma once
#include <SFML/Graphics.hpp>

class View : public sf::View
{
private:

public:
	View();
	~View();
};

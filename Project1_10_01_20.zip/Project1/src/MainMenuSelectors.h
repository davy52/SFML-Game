#pragma once

namespace Selector
{
	enum class Main {
		level_select,
		character,
		profile,
		skin,
		settings,
		help,
		exit
	} main;

	enum class Level
	{

	} Level;

	enum class Character
	{

	} Level;


};
